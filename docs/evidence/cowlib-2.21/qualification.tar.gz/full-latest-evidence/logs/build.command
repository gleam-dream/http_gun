gleam
build
--warnings-as-errors
