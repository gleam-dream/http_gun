python3
dev/check_batch.py
