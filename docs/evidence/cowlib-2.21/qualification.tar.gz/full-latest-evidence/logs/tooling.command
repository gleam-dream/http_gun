nix
flake
check
--print-build-logs
