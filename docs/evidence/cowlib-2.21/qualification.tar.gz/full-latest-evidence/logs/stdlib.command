python3
dev/check_stdlib.py
