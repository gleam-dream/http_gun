gleam
format
--check
src
test
dev
examples
