## Foreign boundary and dependency upgrades

Translate native operations without moving policy out of Gleam.

### md-table

| Bridge | Allowed responsibility | Upgrade-sensitive contract |
| --- | --- | --- |
| Gun bindings | Start/open/request/update_flow/cancel/close, supported info lookup and terminal event forwarding | Asynchronous request submission; protocol choice; no replay; H1 state_name inspection; terminal cause sent to the original owner before Gun exits |
| Event conversion | Up/down/head/data/trailers/inform/upgrade/settings conversion to typed events | Structured error shapes; H2 pseudo-header counting; initial capacity changes |
| Runtime primitives | Monotonic time, atomic batch counter, exception-safe scopes and address/DNS conversion and OTP PEM/DER identity admission | VM-local clocks; whole-byte/IP conversion; narrow trusted boundaries |
| Filesystem primitives | Unique directory candidate, empty-directory/direct-entry cleanup | Exclusive creation remains in Gleam; nonrecursive best-effort removal |

- No handwritten Erlang pool, body server, recorder server, DNS admission server or protocol parser exists. Native exception classification returns bounded recognized causes and UnknownTransport. Internal module visibility is documentation organization rather than an import-security boundary; opaque capability construction and actors enforce authority.
- Gun range is 2.6.0 inclusive to 2.7.0 exclusive. Cowlib range is 2.21.0 inclusive to 2.22.0 exclusive. Patch ranges permit security updates while minor changes require deliberate audit. The committed manifest selects the tested minimum; latest-patch isolated resolution exercises the other end. ADR-0007
- Undocumented assumptions are H1 `gun:info` state_name connected; reason terms inside gun_error/gun_down; Gun terminal event callback before process exit; source-reviewed request return timing; H2 max_headers including status; and test-only cow_http2/cow_hpack calls. Unknown state rejects reuse; unknown reasons lose precision rather than becoming safe-retry evidence.
- Widening a range requires inspecting each assumption, updating decoding only under an accepted contract, running minimum/latest full gates and qualifying public consumers. A changed test helper API can break H2 evidence and must not be mistaken for a production protocol change. `docs/DEPENDENCY-UPGRADES.md` holds the operational procedure.

